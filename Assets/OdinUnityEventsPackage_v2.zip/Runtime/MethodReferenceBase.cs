// SPDX-License-Identifier: MIT
// Odin Unity Events — Runtime
// File: MethodReferenceBase.cs
//
// Purpose:
//   UnityEvent-like method reference powered by Odin serialization.
//   Stores a UnityEngine.Object target + a validated method name and resolves
//   to a cached delegate at runtime; falls back to reflection if necessary.
//
// Key design:
//   * Signature filtering with contravariant-safe check for interface params
//     (listener parameter type must be assignable FROM the event's generic type).
//   * Works with private methods via reflection fallback.
//
// Requirements:
//   * Odin Inspector + Serializer
//
using System;
using System.Linq;
using System.Reflection;
using UnityEngine;
#if HAS_ODIN_INSPECTOR
using Sirenix.OdinInspector;
using Sirenix.Serialization;
#endif

namespace OdinEvents
{
    [Serializable]
    public abstract class MethodReferenceBase
    {
#if HAS_ODIN_INSPECTOR
        [OdinSerialize, Required, HorizontalGroup("h1", Width = 250), LabelText("Target"), InlineButton(nameof(ClearTarget), "✕")]
#endif
        private UnityEngine.Object _target;

#if HAS_ODIN_INSPECTOR
        [OdinSerialize, HorizontalGroup("h1"), LabelText("Method"), ValueDropdown(nameof(GetMethodDropdown))]
#endif
        private string _methodName;

        [NonSerialized] private bool _resolved;
        [NonSerialized] private MethodInfo _method;
        [NonSerialized] private Delegate _cachedDelegate;
        [NonSerialized] protected string _validationMessage;

#if HAS_ODIN_INSPECTOR
        [ShowIf(nameof(HasValidation)), InfoBox("@_validationMessage", InfoMessageType.Error)]
        [HideLabel, ReadOnly]
#endif
        public string Validation => _validationMessage;
        private bool HasValidation => !string.IsNullOrEmpty(_validationMessage);

        protected abstract Type[] Signature();
        protected abstract Type ReturnType();

        protected object Target => _target;
        protected MethodInfo Method => _method;

        private void ClearTarget()
        {
            _target = null;
            _methodName = null;
            Invalidate();
        }

        protected void Invalidate()
        {
            _resolved = false;
            _method = null;
            _cachedDelegate = null;
            _validationMessage = null;
        }

#if HAS_ODIN_INSPECTOR
        private ValueDropdownList<string> GetMethodDropdown()
        {
            var list = new ValueDropdownList<string>();
            if (_target == null) { list.Add("(assign a target)", null); return list; }

            var type = _target.GetType();
            var flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
            var sig = Signature();
            var ret = ReturnType();

            var methods = type.GetMethods(flags)
                .Where(m => !m.IsAbstract && !m.IsGenericMethodDefinition)
                .Where(m => ret == null || m.ReturnType == ret)
                .Where(m =>
                {
                    var ps = m.GetParameters();
                    if (ps.Length != sig.Length) return false;
                    for (int i = 0; i < ps.Length; i++)
                    {
                        // SAFER: listener param type must accept values of sig[i]
                        if (!ps[i].ParameterType.IsAssignableFrom(sig[i])) return false;
                    }
                    return true;
                })
                .OrderBy(m => m.Name);

            int count = 0;
            foreach (var m in methods)
            {
                var label = $"{m.DeclaringType.Name}.{m.Name}({string.Join(", ", m.GetParameters().Select(p => p.ParameterType.Name))})";
                list.Add(label, m.Name);
                count++;
            }
            if (count == 0) list.Add("(no compatible methods)", null);
            return list;
        }
#endif

        protected bool TryResolve()
        {
            if (_resolved) return _method != null;
            _validationMessage = null;
            if (_target == null) { _validationMessage = "Assign a target."; _resolved = true; return false; }
            if (string.IsNullOrEmpty(_methodName)) { _validationMessage = "Pick a method."; _resolved = true; return false; }

            var type = _target.GetType();
            var flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
            _method = type.GetMethod(_methodName, flags, null, Signature(), null);
            if (_method == null) { _validationMessage = $"Method '{_methodName}' not found on {type.Name}."; _resolved = true; return false; }
            if (ReturnType() != null && _method.ReturnType != ReturnType()) { _validationMessage = "Return type mismatch."; _resolved = true; return false; }
            _resolved = true; return true;
        }

        protected bool TryCreateDelegate(Type delegateType, out Delegate del)
        {
            del = null;
            if (!TryResolve()) return false;
            try
            {
                _cachedDelegate ??= Delegate.CreateDelegate(delegateType, Target, Method, true);
                del = _cachedDelegate;
                if (del == null) throw new Exception("CreateDelegate returned null.");
                return true;
            }
            catch
            {
                return false; // use reflection fallback
            }
        }

        protected void InvokeReflection(params object[] args) => Method.Invoke(Target, args);
    }
}
