# OdinEvents (Odin-Drawer Edition)

A UnityEvent-like system with Odin-driven inspector:
- Target + Method picker UI
- Per-parameter bindings: Constant / EventArgN / Interface (drag or inline via [SerializeReference])
- Optional AYellowpaper integration (define `AYSI` to use SerializedInterface<T> for drag-and-drop interfaces).

## Install
1. Copy `Assets/OdinEvents` into your project.
2. Make sure you have **Odin Inspector** (for the drawer) installed.
3. (Optional) Install **AYellowpaper/Serialize Interfaces!** and add scripting define `AYSI` for best drag-and-drop interface UX.

## Try it
- Add `OdinEventsSample` to a GameObject.
- Add a listener: Target = same object; Method = `LogWithScore(IScorer,string,int)`
- For the interface parameter use Interface binding, choose inline `SumScorer` and set `bonus`.
- Press `Test Invoke`.
