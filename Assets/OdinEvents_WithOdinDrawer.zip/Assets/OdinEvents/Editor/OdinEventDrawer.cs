// Assets/OdinEvents/Editor/OdinEventDrawer.cs
#if UNITY_EDITOR
using System;
using System.Linq;
using System.Reflection;
using Sirenix.OdinInspector.Editor;
using Sirenix.Utilities;
using Sirenix.Utilities.Editor;
using UnityEditor;
using UnityEngine;

namespace OdinEvents.Editor
{
    // Draws any OdinEventBase field to look/feel like UnityEvent.
    public class OdinEventBaseDrawer : OdinValueDrawer<OdinEvents.OdinEventBase>
    {
        protected override void DrawPropertyLayout(GUIContent label)
        {
            var value = this.ValueEntry.SmartValue;
            if (value == null)
            {
                SirenixEditorGUI.ErrorMessageBox("Null event instance.");
                CallNextDrawer(label);
                return;
            }

            SirenixEditorGUI.BeginBox(label);
            var calls = value.GetType().GetField("_persistentCalls", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(value) as System.Collections.IList;
            var exts  = value.GetType().GetField("_extendedBindings", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(value) as System.Collections.IList;

            for (int i = 0; i < calls.Count; i++)
            {
                DrawCallRow(value, calls, exts, i);
                GUILayout.Space(2);
            }

            if (SirenixEditorGUI.ToolbarButton(EditorIcons.Plus))
            {
                var addMethod = value.GetType().GetMethod("AddListener");
                addMethod.Invoke(value, new object[] { null, "", new OdinEvents.ArgBinding[0] });
                GUIHelper.RequestRepaint();
            }

            SirenixEditorGUI.EndBox();
            this.ValueEntry.ApplyChangedReferences();
        }

        private void DrawCallRow(OdinEvents.OdinEventBase evt, System.Collections.IList calls, System.Collections.IList exts, int index)
        {
            var call = calls[index] as OdinEvents.PersistentCall;
            var ext  = exts[index]  as OdinEvents.ArgBindingEx;

            SirenixEditorGUI.BeginBox();
            SirenixEditorGUI.BeginBoxHeader();
            GUILayout.Label($"Listener {index+1}", SirenixGUIStyles.BoldLabel);
            GUILayout.FlexibleSpace();
            if (SirenixEditorGUI.IconButton(EditorIcons.Minus))
            {
                evt.RemoveAt(index);
                SirenixEditorGUI.EndBoxHeader(); SirenixEditorGUI.EndBox();
                return;
            }
            SirenixEditorGUI.EndBoxHeader();

            GUILayout.Space(2);

            // Target
            var newTarget = SirenixEditorFields.UnityObjectField("Target", call.target, typeof(UnityEngine.Object), true);
            if (newTarget != call.target) { call.target = newTarget; call.ClearCache(); }

            // Method picker
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.PrefixLabel("Method");
                if (GUILayout.Button(string.IsNullOrEmpty(call.methodName) ? "(Select Method)" : call.methodName, GUILayout.MaxWidth(240)))
                {
                    ShowMethodPicker(call);
                }
            }

            // Parameter bindings UI
            if (call.TryGetMethod(out var method))
            {
                var pis = method.GetParameters();
                EnsureArgCount(call, pis.Length);
                GUILayout.Space(2);
                for (int p = 0; p < pis.Length; p++)
                {
                    DrawParamBinding(pis[p].ParameterType, call, ext, p);
                }
            }
            else
            {
                SirenixEditorGUI.InfoMessageBox("Pick a target + method.");
            }

            SirenixEditorGUI.EndBox();
        }

        private void EnsureArgCount(OdinEvents.PersistentCall call, int count)
        {
            while (call.arguments.Count < count) call.arguments.Add(new OdinEvents.ArgBinding());
        }

        private void DrawParamBinding(Type expectedType, OdinEvents.PersistentCall call, OdinEvents.ArgBindingEx ext, int index)
        {
            SirenixEditorGUI.BeginBox();
            GUILayout.Label($"Parameter {index+1}: {expectedType.GetNiceName()}", SirenixGUIStyles.LabelCentered);
            GUILayout.Space(2);

            // If the method expects an interface, offer Interface binding UI
            if (expectedType.IsInterface)
            {
                using (new EditorGUILayout.HorizontalScope())
                {
                    GUILayout.Label("Source", GUILayout.Width(60));
                    bool useInterface = ext != null && ext.GetType().GetField("kind", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(ext).ToString() == "Interface";
                    bool toggle = EditorGUILayout.ToggleLeft("Interface (drag or inline)", useInterface);
                    if (toggle && !useInterface)
                    {
                        // Create InterfaceArg<T> instance and box it
                        var ifaceArgType = typeof(OdinEvents.InterfaceArg<>).MakeGenericType(expectedType);
                        var boxed = Activator.CreateInstance(ifaceArgType);
                        if (ext == null)
                        {
                            var evt = this.ValueEntry.SmartValue;
                            var exts = evt.GetType().GetField("_extendedBindings", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(evt) as System.Collections.IList;
                            while (exts.Count < (evt.PersistentCalls.Count)) exts.Add(new OdinEvents.ArgBindingEx());
                            ext = exts[exts.Count - 1] as OdinEvents.ArgBindingEx;
                        }
                        ext.SetInterfaceBoxed(boxed);
                    }
                    else if (!toggle && useInterface)
                    {
                        // reset to None by reboxing null
                        ext.SetInterfaceBoxed(null);
                    }
                }

                if (ext != null && ext.HasInterface)
                {
                    // Draw the boxed InterfaceArg<T> with Odin recursively
                    var boxed = ext.GetType().GetField("boxedInterfaceArg", BindingFlags.NonPublic | BindingFlags.Instance).GetValue(ext);
                    SirenixEditorFields.UnityPreviewObjectField("Inline/UnityObject", boxed as UnityEngine.Object, false);
                    SirenixEditorFields.UnityObjectField(" ", null, typeof(UnityEngine.Object), true); // spacer

                    // Let Odin draw full object inspector for the boxed instance
                    SirenixEditorGUI.DrawUnityObject(boxed as UnityEngine.Object, true);
                    SirenixEditorGUI.PropertyField(boxed, true);
                    SirenixEditorGUI.HorizontalLineSeparator();
                    SirenixEditorGUI.InfoMessageBox("If AYellowpaper is installed, you can drag any Component or ScriptableObject implementing the interface. Otherwise, assign an inline instance via SerializeReference.");
                    SirenixEditorGUI.EndBox();
                    return;
                }
            }

            // Non-interface or when not using interface binding -> show standard ArgBinding
            var bind = call.arguments[index];
            bind.source = (OdinEvents.ArgSourceKind)SirenixEditorFields.EnumDropdown("Source", bind.source);
            if (bind.source == OdinEvents.ArgSourceKind.Constant)
            {
                var val = bind.constant?.GetValue();
                val = SirenixEditorFields.UniversalField("Constant", val, expectedType, null);
                if (bind.constant == null) bind.constant = new OdinEvents.SerializedConstant();
                bind.constant.SetValue(val);
            }
            SirenixEditorGUI.EndBox();
        }

        private void ShowMethodPicker(OdinEvents.PersistentCall call)
        {
            var menu = new GenericMenu();
            if (call.target == null)
            {
                menu.AddDisabledItem(new GUIContent("Assign a Target first"));
                menu.ShowAsContext();
                return;
            }
            var type = call.target.GetType();
            var methods = type.GetMethods(BindingFlags.Instance | BindingFlags.Public)
                              .Where(m => !m.IsSpecialName);
            foreach (var m in methods)
            {
                var pi = m.GetParameters();
                string label = $"{m.Name}({string.Join(", ", pi.Select(p => p.ParameterType.GetNiceName()))})";
                menu.AddItem(new GUIContent(label), false, () =>
                {
                    call.methodName = m.Name;
                    call.ClearCache();
                });
            }
            menu.ShowAsContext();
        }
    }
}
#endif
