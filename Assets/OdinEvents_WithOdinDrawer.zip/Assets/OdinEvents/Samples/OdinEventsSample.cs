// Assets/OdinEvents/Samples/OdinEventsSample.cs
using UnityEngine;

namespace OdinEvents.Samples
{
    public class OdinEventsSample : MonoBehaviour
    {
        public OdinEvents.OdinEvent<IScorer, string, int> onScored;

        [ContextMenu("Test Invoke")]
        private void TestInvoke()
        {
            onScored.Invoke(new SumScorer(){ bonus = 10 }, "Coins", 100);
        }

        public void LogWithScore(IScorer scorer, string label, int value)
        {
            var s = scorer?.Score(label, value) ?? -1;
            Debug.Log($"[{name}] {label}:{value} -> score {s}");
        }
    }
}
